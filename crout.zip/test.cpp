#include <iostream>
#include <cassert>
#include "csc_matrix.h"

using namespace std;

int main() {
	csc_matrix<int, double> A, L;
	vector<double> D;
	
	assert( A.load("test_matrices/1138_bus.mtx") );
	//cout << A << endl;
	
	A.ildl(L, D, 30, 0.01);
	//cout << L << endl;
	//cout << D << endl;	
	
	return 0;
}

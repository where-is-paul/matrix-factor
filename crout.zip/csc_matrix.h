// -*- mode: c++ -*-
#ifndef _CSC_MATRIX_H_
#define _CSC_MATRIX_H_

#include "abstract_sparse_matrix.h"

template<class idx_type, class el_type> 
class csc_matrix;

#include "csc_matrix_declarations.h"

#endif 
